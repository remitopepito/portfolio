#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  4 11:50:55 2023

@author: remipierron

Chaque commentaire se réfère au code qui se trouve en dessous.
"""
# Rémi PIERRON et Romain VIVIER
#import des bibliothèques de fonction
import time
import csv
import json

#lancement d'un chronomètre pour mesurer la rapidité d'éxécution du programme
temps_debut = time.time()

#ouverture et lecture du fichier json
f = open("comorbidites.json", encoding = 'utf-8')
contenu_json = f.read()

#transformation du fichier json en liste où chaque élément regroupe une liste qui contient le dictionnaire fields qui regroupe les données que l'on cherche
Comorb = json.loads(contenu_json)

#initialisation de variables qui permettent le fonctionnement de la boucle suivante
i = 0
nbelement = len(Comorb)

#création d'une liste qui va contenir les éléments triés
listeFinale= []

for i in range(0, nbelement):
    #initialisation d'une mini-liste dans laquelle on va mettre les données qui nous intéressent
    listeElement = []
    #Comorb[i] correspond à un élément de la liste Comorb. 
    data = Comorb[i]
    #Dans cet enchevêtrement de if, on vérifie pour chaque élément qu'il existe. Si il existe, on le rajoute à la mini-liste, sinon on détruit la mini-liste. 
    if 'fields' in data:
        fields_data = data['fields']
        if 'patho_niv3' in fields_data:
            patho = fields_data['patho_niv3']
            listeElement.append(patho)  
        elif 'patho_niv2' in fields_data:
            patho = fields_data['patho_niv2']
            listeElement.append(patho)
        elif 'patho_niv1' in fields_data:
            patho = fields_data['patho_niv1']
            listeElement.append(patho)
        else:
            del listeElement
            continue
        
        if 'libelle_comorbidite' in fields_data:
            valeur_libelle_comorbidite = fields_data['libelle_comorbidite']
            listeElement.append(valeur_libelle_comorbidite)
        else:
            del listeElement
            continue
        if 'annee' in fields_data:
            valeurAnnee = fields_data['annee']
            listeElement.append(valeurAnnee)
        else:
            del listeElement
            continue
        
        if 'ntop' in fields_data:
            effectPatho = fields_data['ntop']
            listeElement.append(effectPatho)
        else:
            del listeElement
            continue
        
        if 'ncomorb' in fields_data:
            effectComorb = fields_data['ncomorb']
            listeElement.append(effectComorb)
        else:
            del listeElement
            continue
        
        if 'proportion_comorb' in fields_data:
            proporComorb = fields_data['proportion_comorb']
            listeElement.append(proporComorb)
        else:
            del listeElement
            continue
        
        if 'niveau_prioritaire' in fields_data:
            nivPrio = fields_data['niveau_prioritaire']
            listeElement.append(nivPrio)
        else:
            del listeElement
            continue
       
    else:
            del listeElement
            continue
    #on ajoute la mini-liste à la grande liste
    listeFinale.append(listeElement)

#tri du fichier 
listeFinale.sort(key=lambda x: (x[-2], x[0], x[1], x[2]), reverse=True)

#conversion de la proportion en pourcentage pour plus de lisbilité pour l'utilisateur
for row in listeFinale:
    if len(row) >= 6:  
        if isinstance(row[5], float):  
            row[5] = "{:.3f}%".format(float(row[5]) * 100)

#rajout d'entête pour le tableau final
listeEntete = ['Niveau de pathologie', 'Nom de la comorbidité', 'Année', 'Effectif de la pathologie', 'Effectif de la comorbidité', 'Proportion', 'Niveau de priorité']
listeFinale.insert(0, listeEntete)

#conversion en csv et création du fichier csv
with open('donnees_comorbidites.csv', 'w', newline='', encoding='utf-16') as file:
    writer = csv.writer(file, delimiter=';')
    writer.writerows(listeFinale)
#fermeture du fichier json
f.close()
#témoin d'éxecution
print("Votre fichier CSV à été importé avec succès !")
temps_fin = time.time()
duree_execution = temps_fin - temps_debut
print("Le temps d'exécution est de :", round(duree_execution, 2), "secondes")

'''
D'après nos tests, le programme s'éxécute en 0,26 sec sur un MacBook Air avec un processeur M2 et en 0,51 sec sur un PC Windows avec un processeur Intel I5 8th Gen
'''