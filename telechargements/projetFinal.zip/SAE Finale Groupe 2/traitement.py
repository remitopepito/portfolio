import csv
import pandas as pd
import os
import openpyxl

# Faire le "pip install pandas"
# Faire le "pip install openpyxl"

fichier = "accident.csv"
fichier_xlsx = 'MAVIE_BD_STID_mai_2024.xlsx'
fichier_csv = 'accident.csv'
feuille='Accident'
fichier1="modifie_accident.csv"
fichier2="modifie_accident2.csv"
modif1="oui"
modif2="oui"

# Récupère le nom du fichier sur tout le répertoire
def obtenir_nom_fichier(chemin_fichier):
    """
    Cette fonction prend un chemin de fichier en entrée et renvoie le nom du fichier.
    """
    nom_fichier = os.path.basename(chemin_fichier)
    return nom_fichier

# Exemple d'utilisation
# chemin = "/chemin/vers/votre/fichier.txt"
# nom_fichier = obtenir_nom_fichier(chemin)
# print(nom_fichier)  # Affiche: fichier.txt

#Convertie un fichier xlsx en fichier csv
def convertisseur(fichier_xlsx, fichier_csv, feuille):
    # Ouvrir le fichier Excel
    wb = openpyxl.load_workbook(fichier_xlsx)
    ws = wb[feuille]

    # Ouvrir le fichier CSV en écriture
    with open(fichier_csv, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file, delimiter=';')

        # Itérer sur les lignes de la feuille Excel
        for row in ws.iter_rows(values_only=True):
            # Convertir les valeurs en int si elles sont des float sans partie décimale
            new_row = [int(cell) if isinstance(cell, float) and cell.is_integer() else cell for cell in row]
            # Écrire la ligne dans le fichier CSV
            writer.writerow(new_row)

# Fonction pour ouvrir le fichier et le transformer en liste de listes
def ouverture(fichier):
    accListe = []
    nomCol = []
    try:
        with open(fichier, newline='', encoding='utf-8') as csvfile:
            liste = csv.reader(csvfile, delimiter=';')
            for i, ligne in enumerate(liste):
                if i == 0:
                    nomCol = list(ligne)  # Garde dans une liste l'en-tête avec le nom des colonnes
                else:
                    accListe.append(list(ligne))
    except FileNotFoundError:
        print("Fichier introuvable !")
    return accListe, nomCol

# Fonction de modification des colonnes telles que : "précisez le lieux ..."
def modification(accListe, nomCol): 
    nouvelle_accListe = []
    for ligne in accListe:
        if ligne[2] == 'Oui':
            lieuPrecis = ''.join(ligne[10:20])
            activitePratique = ''.join(ligne[21:27])
            sportPratique = ''.join(ligne[29:45])
            nv=ligne[3]
            ligne[3]=nv[:10]
            ligne[10] = lieuPrecis
            ligne[21] = activitePratique
            ligne[29] = sportPratique

        nouvelle_accListe.append(ligne)
    
    # Suppression des colonnes inutiles et mise à jour des noms de colonnes
    for ligne in nouvelle_accListe:
        del ligne[11:20]
        del ligne[13:18]
        del ligne[15:30]

    nomCol[10] = "LieuPrécis"
    nomCol[21] = "ActivitéPratiquée"
    nomCol[29] = "SportPratiqué"

    del nomCol[11:20]
    del nomCol[13:18]
    del nomCol[15:30] 

    fichier_sortie = "accident_traite.csv"

    # Ajouter les noms de colonnes à la première ligne de la nouvelle liste
    nouvelle_accListe.insert(0, nomCol)

    # Réécriture dans un fichier csv pour export
    with open(fichier_sortie, 'w', newline='', encoding='UTF-8') as csvfile:
        writer = csv.writer(csvfile, delimiter=';')
        for ligne in nouvelle_accListe:
            writer.writerow(ligne)

    print("Le fichier CSV a été créé avec succès !")

# Fait la concatenation entre 2 fichier qui contient des accidents
def concatener(fichier1,modif1,fichier2,modif2):
    if fichier1.endswith(".csv"):
        if modif1=="non":
            liste1,nomcol1=ouverture(fichier1)
            modification(liste1,nomcol1)
        else :
            liste1,nomcol1=ouverture(fichier1)
    else :
        convertisseur(fichier1,fichier,feuille)
        liste1,nomcol1=ouverture(fichier1)
        modification(liste1,nomcol1)
    if fichier2.endswith(".csv"):
        if modif2=="non":
            liste2,nomcol2=ouverture(fichier2)
            modification(liste2,nomcol2)
        else :
            liste2,nomcol2=ouverture(fichier2)
    else :
        convertisseur(fichier2,fichier,feuille)
        liste2,nomcol2=ouverture(fichier2)
        modification(liste2,nomcol2)
    for ligne in liste2:
        liste1.append(ligne)
    liste1.insert(0,nomcol1)
    with open(fichier1, 'w', newline='', encoding='UTF-8') as csvfile:
        writer = csv.writer(csvfile, delimiter=';')
        for ligne in liste1:
            writer.writerow(ligne)

    print("Les fichiers ont bien été concatener !")

# Au besoin, on renomme le fichier en "accident_traite.csv"
def renommer_en_accident_traite(chemin_fichier):
    """
    Cette fonction prend un chemin de fichier en entrée et renomme ce fichier en 'accident_traite.csv'.
    """
    try:
        dossier = os.path.dirname(chemin_fichier)
        nouveau_nom = os.path.join(dossier, 'accident_traite.csv')
        os.rename(chemin_fichier, nouveau_nom)
        print("Le fichier a été renommé avec succès.")
        return nouveau_nom
    except Exception as e:
        print(f"Erreur lors du renommage du fichier : {e}")
        return None
        
# Fait la jointure entre la feuille accident et la feuille qui contient les informations des volontaires
def jointure():
    
    convertisseur("MAVIE_BD_STID_mai_2024.xlsx", "indiv.csv", "BD_3quest")
    convertisseur("MAVIE_BD_STID_mai_2024.xlsx", "accident.csv", feuille)
    accListe, nomCol=ouverture("accident.csv")
    modification(accListe, nomCol)
    
    # Charger les fichiers CSV dans des DataFrames en utilisant l'encodage iso-8859-1
    df_accidents = pd.read_csv("accident_traite.csv", delimiter=";", encoding="iso-8859-1")
    df_indiv = pd.read_csv("indiv.csv", delimiter=";", encoding="iso-8859-1")
    
    # Effectuer la jointure entre les deux DataFrames en utilisant la colonne Id_volontaire
    df_joint = pd.merge(df_accidents, df_indiv, on="Id_volontaire")
    
    # Afficher les premières lignes du DataFrame résultant
    print(df_joint.head())
    
    # Enregistrer le DataFrame résultant dans un nouveau fichier CSV
    df_joint.to_csv("data.csv", index=False, sep=';')

# Exécuter les fonctions
# convertisseur(fichier_xlsx, fichier_csv,feuille)
#accListe, nomCol = ouverture(fichier_csv)
#modification(accListe, nomCol)
#concatener(fichier1,modif1,fichier2,modif2)