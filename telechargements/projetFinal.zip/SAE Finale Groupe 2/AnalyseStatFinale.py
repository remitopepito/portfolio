from scipy.stats import chi2_contingency
import pandas as pd
import chardet
import tkinter as tk
from tkinter import ttk

# pour détecter l'encodage du fichier
def detect_encoding(file_path):
    with open(file_path, 'rb') as file:
        result = chardet.detect(file.read())
    return result['encoding']

# pour lire le fichier avec le bon encodage
def read_csv_with_encoding(file_path, delimiter, encoding):
    return pd.read_csv(file_path, delimiter=delimiter, encoding=encoding)

# Calcul la part des individus accidentés en fonction du sexe
def calculate_sex_parts(df):
    df_acc = df[df['Acc'] == 'Oui']
    df_acc.loc[:, 'Annee_nais'] = pd.to_numeric(df_acc.loc[:, 'Annee_nais'])
    sex_counts = df_acc['Sexe'].value_counts()
    sex_parts = sex_counts / df_acc.shape[0]
    return sex_parts

# calcul la part des accidentés par tranche d'âge de 10 ans
def calculate_age_parts(df):
    df_acc = df[df['Acc'] == 'Oui']
    df_acc.loc[:, 'Age_dizaine'] = (df_acc.loc[:, 'Age_actuel'] // 10) * 10
    df_acc = df_acc[df_acc['Age_dizaine'] != 0]
    age_counts = df_acc['Age_dizaine'].value_counts()
    age_parts = age_counts / df_acc.shape[0]
    age_parts_sorted = age_parts.sort_values(ascending=False)
    return age_parts_sorted

# calcul la proportion des personnes qui ont un escalier dans leur logement parmi les accidentés
def calculate_escalier_proportion(df, column_name):
    df[column_name] = df[column_name].str.replace('Oui', '1').str.replace('Non', '0')
    df[column_name] = pd.to_numeric(df[column_name])
    return df[column_name].mean()

# Répartition des types de logements parmi les accidentés
def calculate_type_logement_parts(df):
    # Filtrer pour ne garder que les lignes où 'Acc' est 'Oui'
    df_acc = df[df['Acc'] == 'Oui']
    
    # Compter les types de logement parmi les accidentés
    type_log_counts = df_acc['Type_log'].value_counts()
    
    # Calculer les proportions
    type_log_parts = type_log_counts / df_acc.shape[0]
    
    # Trier les proportions
    type_log_parts_sorted = type_log_parts.sort_values(ascending=False)
    
    return type_log_parts_sorted

# Répartition des types de logements dans la population totale
def calculate_type_logement_parts_total(df):
    type_log_counts = df['Type_log'].value_counts()
    type_log_parts = type_log_counts / df.shape[0]
    type_log_parts_sorted = type_log_parts.sort_values(ascending=False)
    return type_log_parts_sorted

# Répartition des accidents par département
def calculate_department_distribution(df):
    df['Code_postal'] = df['CP_acc'].astype(str)
    df['Code_postal_2'] = df['Code_postal'].str[:2]
    code_postal_counts = df['Code_postal_2'].value_counts()
    return code_postal_counts

# Répartition des accidents par type de situation familiale
def calculate_situation_familiale_parts(df):
    sit_fam_counts = df['Sit_fam'].value_counts()
    sit_fam_parts = sit_fam_counts / df.shape[0]
    sit_fam_parts_sorted = sit_fam_parts.sort_values(ascending=False)
    return sit_fam_parts_sorted

# test du khi-deux pour voir s'il y a indépendance ou non entre avoir un accident et le genre
def calculer_khi_deux(df, colonne1, colonne2):
    if colonne1 not in df.columns or colonne2 not in df.columns:
        raise ValueError("Colonne non trouvée dans le DataFrame.")
    if not isinstance(df, pd.DataFrame):
        raise TypeError("df doit être un DataFrame pandas.")
    table_cont = pd.crosstab(df[colonne1], df[colonne2])
    khi2_cal, p_val, ddl, effectif_theorique = chi2_contingency(table_cont)
    resultats = {
        'statistique_khi_deux': khi2_cal,
        'p_valeur': p_val,
        'degres_de_liberte': ddl,
        'effectifs_theoriques': effectif_theorique,
        'table_contingence': table_cont
    }
    return resultats

# Page Tkinter qui affiche toutes les données calculées à partir des fonctions et procédures précédentes
class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Analyse Statistique Finale")
        self.geometry("800x600")
        self.create_widgets()
    
    def create_widgets(self):
        # Création d'un frame principal
        self.main_frame = ttk.Frame(self)
        self.main_frame.pack(fill=tk.BOTH, expand=1)
        
        # Création d'un canvas
        self.canvas = tk.Canvas(self.main_frame)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=1)
        
        # Ajout d'une scrollbar au canvas
        self.scrollbar = ttk.Scrollbar(self.main_frame, orient=tk.VERTICAL, command=self.canvas.yview)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Configurer le canvas
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        
        # Création d'un autre frame à l'intérieur du canvas
        self.second_frame = ttk.Frame(self.canvas)
        
        # Ajout de ce second frame dans un window du canvas
        self.canvas.create_window((0, 0), window=self.second_frame, anchor="nw")
        
        # Ajout de widgets pour afficher les résultats
        self.sex_label = ttk.Label(self.second_frame, text="Répartition des sexes parmi les accidentés:")
        self.sex_label.grid(row=1, column=0, sticky=tk.W)
        
        self.sex_text = tk.Text(self.second_frame, width=60, height=3)
        self.sex_text.grid(row=1, column=1)
        
        self.age_label = ttk.Label(self.second_frame, text="Répartition des âges par dizaines parmi les accidentés:")
        self.age_label.grid(row=2, column=0, sticky=tk.W)
        
        self.age_text = tk.Text(self.second_frame, width=60, height=8)
        self.age_text.grid(row=2, column=1)
        
        self.escalier_acc_label = ttk.Label(self.second_frame, text="Proportion de personnes avec escalier parmi les accidentés:")
        self.escalier_acc_label.grid(row=3, column=0, sticky=tk.W)
        
        self.escalier_acc_text = tk.Text(self.second_frame, width=60, height=1)
        self.escalier_acc_text.grid(row=3, column=1)
        
        self.escalier_total_label = ttk.Label(self.second_frame, text="Proportion de personnes avec escalier dans la population totale:")
        self.escalier_total_label.grid(row=4, column=0, sticky=tk.W)
        
        self.escalier_total_text = tk.Text(self.second_frame, width=60, height=1)
        self.escalier_total_text.grid(row=4, column=1)
        
        self.type_log_acc_label = ttk.Label(self.second_frame, text="Répartition des types de logement parmi les accidentés:")
        self.type_log_acc_label.grid(row=5, column=0, sticky=tk.W)
        
        self.type_log_acc_text = tk.Text(self.second_frame, width=60, height=4)
        self.type_log_acc_text.grid(row=5, column=1)
        
        self.type_log_total_label = ttk.Label(self.second_frame, text="Répartition des types de logement dans la population totale:")
        self.type_log_total_label.grid(row=6, column=0, sticky=tk.W)
        
        self.type_log_total_text = tk.Text(self.second_frame, width=60, height=10)
        self.type_log_total_text.grid(row=6, column=1)
        
        self.departement_label = ttk.Label(self.second_frame, text="Répartition des accidents par département:")
        self.departement_label.grid(row=7, column=0, sticky=tk.W)
        
        self.departement_text = tk.Text(self.second_frame, width=60, height=10)
        self.departement_text.grid(row=7, column=1)
        
        self.sit_fam_label = ttk.Label(self.second_frame, text="Répartition des accidents par situation familiale:")
        self.sit_fam_label.grid(row=8, column=0, sticky=tk.W)
        
        self.sit_fam_text = tk.Text(self.second_frame, width=60, height=5)
        self.sit_fam_text.grid(row=8, column=1)
        
        # Widgets pour afficher les résultats du test du Khi-deux
        self.khi_deux_label = ttk.Label(self.second_frame, text="Résultats du test du Khi-deux (Accidents vs Sexe):")
        self.khi_deux_label.grid(row=9, column=0, sticky=tk.W)
        
        self.khi_deux_text = tk.Text(self.second_frame, width=60, height=6)
        self.khi_deux_text.grid(row=9, column=1)
        
        # Ajout d'un bouton pour mettre à jour les résultats
        self.update_button = ttk.Button(self.second_frame, text="Mettre à jour", command=self.update_results)
        self.update_button.grid(row=0, column=0, columnspan=2, pady=5)
        
    def update_results(self):
        # Obtenir les données
        encoding = detect_encoding('data.csv')
        df = read_csv_with_encoding('data.csv', delimiter=';', encoding=encoding)
        df_indiv = read_csv_with_encoding("indiv.csv", delimiter=";", encoding="iso-8859-1")
        
        sex_parts = calculate_sex_parts(df)
        self.sex_text.delete(1.0, tk.END)
        self.sex_text.insert(tk.END, str(sex_parts))
        
        age_parts_sorted = calculate_age_parts(df)
        self.age_text.delete(1.0, tk.END)
        self.age_text.insert(tk.END, str(age_parts_sorted))
        
        prop_escalier_acc = calculate_escalier_proportion(df, 'Escaliers_int')
        self.escalier_acc_text.delete(1.0, tk.END)
        self.escalier_acc_text.insert(tk.END, f"{prop_escalier_acc:.2%}")
        
        prop_escalier_total = calculate_escalier_proportion(df_indiv, 'Escaliers_int')
        self.escalier_total_text.delete(1.0, tk.END)
        self.escalier_total_text.insert(tk.END, f"{prop_escalier_total:.2%}")
        
        type_log_parts_acc = calculate_type_logement_parts(df)
        self.type_log_acc_text.delete(1.0, tk.END)
        self.type_log_acc_text.insert(tk.END, str(type_log_parts_acc))
        
        type_log_parts_indiv = calculate_type_logement_parts_total(df_indiv)
        self.type_log_total_text.delete(1.0, tk.END)
        self.type_log_total_text.insert(tk.END, str(type_log_parts_indiv))
        
        code_postal_counts = calculate_department_distribution(df)
        self.departement_text.delete(1.0, tk.END)
        self.departement_text.insert(tk.END, str(code_postal_counts))
        
        sit_fam_parts_sorted = calculate_situation_familiale_parts(df)
        self.sit_fam_text.delete(1.0, tk.END)
        self.sit_fam_text.insert(tk.END, str(sit_fam_parts_sorted))
        
        # Calcul et affichage des résultats du test du Khi-deux
        resultats_khi_deux = calculer_khi_deux(df, 'Acc', 'Sexe')
        if resultats_khi_deux:
            self.khi_deux_text.delete(1.0, tk.END)
            self.khi_deux_text.insert(tk.END, f"Statistique du khi-deux: {resultats_khi_deux['statistique_khi_deux']}\n")
            self.khi_deux_text.insert(tk.END, f"P-valeur: {resultats_khi_deux['p_valeur']}\n")
            self.khi_deux_text.insert(tk.END, f"Degrés de liberté: {resultats_khi_deux['degres_de_liberte']}\n")
            self.khi_deux_text.insert(tk.END, f"Effectifs théoriques:\n{resultats_khi_deux['effectifs_theoriques']}\n")

if __name__ == "__main__":
    app = Application()
    app.mainloop()
